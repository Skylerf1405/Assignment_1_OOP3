package utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

import shapes.*;
public class reader
{
	private List <Shape> shapes = new ArrayList<>();
	
	public void ReadTenShapes() throws FileNotFoundException
	{
		try (Scanner scanner = new Scanner(new File("res/shapes1.txt")))
		{
			while (scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				String[] data = line.split(" ");
				String shapeType = data[0];
				
				switch(shapeType)
				{
					case "Cone":
						shapes.add(new Cone(
								shapeType, 
								Double.parseDouble(data[1]), 
								Double.parseDouble(data[2])));
						break;
					case "Cylinder":
						shapes.add(new Cylinder(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "OctagonalPrism":
						shapes.add(new OctagonalPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "PentagonalPrism":
						shapes.add(new PentagonalPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "Pyramid":
						shapes.add(new Pyramid(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "SquarePrism":
						shapes.add(new SquarePrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "TriangularPrism":
						shapes.add(new TriangularPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					
					
				}
				
			}
		}
		catch (FileNotFoundException e)
		{
			System.out.println("File not found");
			e.printStackTrace();
		}
		
	}
	
	public void ReadOneThousandShapes() throws FileNotFoundException
	{
		try (Scanner scanner = new Scanner(new File("res/shapes2.txt")))
		{
			while (scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				String[] data = line.split(" ");
				String shapeType = data[0];
				
				switch(shapeType)
				{
					case "Cone":
						shapes.add(new Cone(
								shapeType, 
								Double.parseDouble(data[1]), 
								Double.parseDouble(data[2])));
						break;
					case "Cylinder":
						shapes.add(new Cylinder(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "OctagonalPrism":
						shapes.add(new OctagonalPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "PentagonalPrism":
						shapes.add(new PentagonalPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "Pyramid":
						shapes.add(new Pyramid(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "SquarePrism":
						shapes.add(new SquarePrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "TriangularPrism":
						shapes.add(new TriangularPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					
					
				}
				
			}
		}
		catch (FileNotFoundException e)
		{
			System.out.println("File not found");
			e.printStackTrace();
		}
		
	}
	
	public void ReadOneMillionShapes() throws FileNotFoundException
	{
		try (Scanner scanner = new Scanner(new File("res/shapes3.txt")))
		{
			while (scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				String[] data = line.split(" ");
				String shapeType = data[0];
				
				switch(shapeType)
				{
					case "Cone":
						shapes.add(new Cone(
								shapeType, 
								Double.parseDouble(data[1]), 
								Double.parseDouble(data[2])));
						break;
					case "Cylinder":
						shapes.add(new Cylinder(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "OctagonalPrism":
						shapes.add(new OctagonalPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "PentagonalPrism":
						shapes.add(new PentagonalPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "Pyramid":
						shapes.add(new Pyramid(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "SquarePrism":
						shapes.add(new SquarePrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					case "TriangularPrism":
						shapes.add(new TriangularPrism(
								shapeType,
								Double.parseDouble(data[1]),
								Double.parseDouble(data[2])));
						break;
					
					
				}
				
			}
		}
		catch (FileNotFoundException e)
		{
			System.out.println("File not found");
			e.printStackTrace();
		}
		
	}
	public List<Shape> getShapes() {
	    return shapes;
	}


}
