package utilities;

import shapes.Shape;
import java.util.Comparator;

public class VolumeComparator implements Comparator<Shape> {
    @Override
    public int compare(Shape shape1, Shape shape2) {
        double volume1 = shape1.calcVolume();
        double volume2 = shape2.calcVolume();
        return Double.compare(volume1, volume2);
    }
}