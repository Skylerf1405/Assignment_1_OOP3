package shapes;

public class PentagonalPrism extends Prism
{

	public PentagonalPrism(String shapeName, double height, double side)
	{
		super(shapeName, height, side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calcBaseArea()
	{
		return 1/4 * Math.sqrt(5 * (5 + 2 * Math.sqrt(5))) * Math.pow(getSide(), 2);
	}
	
	@Override
	public double calcVolume()
	{
		return calcBaseArea() * getHeight();
	}

	@Override
	public String toString()
	{
		return "PentagonalPrism - Side: " + getSide() + ", Volume: " + calcVolume() + ", Base Area: "
				+ calcBaseArea() + ", Height" + getHeight();
	}
	
	
}
