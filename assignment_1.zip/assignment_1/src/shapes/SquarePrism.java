package shapes;

/**
 * SquarePrism
 */
public class SquarePrism extends Prism
{
	/**
	 * Creates a square prism with specified height and side
	 * @param height
	 * @param side
	 */
	public SquarePrism(String shapeName, double height, double side)
	{
		super(shapeName, height, side);
	}

	@Override
	public double calcBaseArea()
	{
		// TODO Auto-generated method stub
		return getSide() * getSide();
	}

	@Override
	public String toString()
	{
		return "SquarePrism - Side: " + getSide() + ", Base Area: " + calcBaseArea() + ", Volume: "
				+ calcVolume();
	}
	
}
