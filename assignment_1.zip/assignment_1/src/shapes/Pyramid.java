package shapes;

public class Pyramid extends Prism
{

	public Pyramid(String shapeName, double height, double side)
	{
		super(shapeName, height, side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calcBaseArea()
	{
		return getSide() * getHeight();
	}
	
	@Override
	public double calcVolume()
	{
		return (Math.pow(getSide(), 2) * getHeight()) / 3;
	}

	@Override
	public String toString()
	{
		return "Pyramid - Side: " + getSide() + ", Volume: " + calcVolume() + ", Base Area: "
				+ calcBaseArea() + ", Height: " + getHeight();
	}
	
	
}
