package shapes;

public class TriangularPrism extends Prism
{

	public TriangularPrism(String shapeName, double height, double side)
	{
		super(shapeName, height, side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calcBaseArea()
	{
		return 0.5 * getSide() * getHeight();
	}
	
	@Override
	public double calcVolume()
	{
		return calcBaseArea() * getSide();
	}

	@Override
	public String toString()
	{
		return "TriangularPrism - Side: " + getSide() + ", Volume: " + calcVolume() + ", Base Area: "
				+ calcBaseArea() + ", Height: " + getHeight();
	}
	
	
}
