package shapes;

public class OctagonalPrism extends Prism	
{

	public OctagonalPrism(String shapeName, double height, double side)
	{
		super(shapeName, height, side);
	}
	
	
	@Override
	public double calcVolume()
	{
		return calcBaseArea() * getHeight();
	}

	@Override
	public double calcBaseArea()
	{
		return 2 * (1 + Math.sqrt(2)) * Math.pow(getSide(), 2);
	}


	@Override
	public String toString()
	{
		return "OctagonalPrism - Side: " + getSide() + ", Base Area: " + calcBaseArea() + ", Volume: "
				+ calcVolume() + ", Height: " + getHeight();
	}
	
	
}
