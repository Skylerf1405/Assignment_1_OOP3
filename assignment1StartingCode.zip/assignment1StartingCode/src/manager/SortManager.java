package manager;

import shapes.Shape;
import utilities.*;

import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.List;

public class SortManager {
    private String fileName;
    private String compareType;
    private String sortAlgorithm;
    private Shape[] shapes;
    private reader shapeReader;

    public SortManager(String[] args) {
        parseArguments(args);
        shapeReader = new reader();
    }

    private void parseArguments(String[] args) {
        for (String arg : args) {
            if (arg.startsWith("-f")) {
                fileName = arg.substring(2);
            } else if (arg.startsWith("-t")) {
                compareType = arg.substring(2).toLowerCase();
            } else if (arg.startsWith("-s")) {
                sortAlgorithm = arg.substring(2).toLowerCase();
            }
        }
        if (fileName == null || compareType == null || sortAlgorithm == null) {
            throw new IllegalArgumentException("Invalid arguments. Usage: -f<file_name> -t<compare_type> -s<sort_algorithm>");
        }
    }

    public void readShapes() throws FileNotFoundException {
        if (!fileName.matches("shapes[123]\\.txt")) {
            throw new IllegalArgumentException("Invalid file name: " + fileName + ". Expected shapes1.txt, shapes2.txt, or shapes3.txt");
        }
        
        if (fileName.equals("shapes1.txt")) {
            shapeReader.ReadTenShapes();
        } else if (fileName.equals("shapes2.txt")) {
            shapeReader.ReadOneThousandShapes();
        } else if (fileName.equals("shapes3.txt")) {
            shapeReader.ReadOneMillionShapes();
        }
        List<Shape> shapeList = shapeReader.getShapes();
        shapes = shapeList.toArray(new Shape[0]);
    }

    public void sortShapes() {
        Comparator<Shape> comparator = null;
        switch (compareType) {
            case "h":
                // natural ordering - height
                break;
            case "v":
                comparator = new VolumeComparator();
                break;
            case "a":
                comparator = new BaseAreaComparator();
                break;
            default:
                throw new IllegalArgumentException("Invalid compare type: " + compareType);
        }

        long startTime = System.nanoTime();
        if (comparator == null) {
            Sort.sort(shapes, sortAlgorithm, true); // true for ascending
        } else {
            Sort.sort(shapes, comparator, sortAlgorithm, true); 
        }
        long endTime = System.nanoTime();
        long duration = (endTime - startTime) / 1_000_000; // convert to miliiseconds

        System.out.println("Sort completed in " + duration + " ms");
    }

    public void displayResults() {
        System.out.println("First: " + shapes[0].toString());
        System.out.println("Last: " + shapes[shapes.length - 1]);
        for (int i = 999; i < shapes.length; i += 1000) {
            System.out.println(shapes[i]);
        }
    }
}