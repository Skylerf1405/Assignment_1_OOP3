package manager;

public class SortManager
{

	public SortManager(String[] args)
	{
		// TODO Auto-generated constructor stub
	}

}
