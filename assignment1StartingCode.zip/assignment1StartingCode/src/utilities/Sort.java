package utilities;

import java.util.Comparator;

public class Sort
{
	public static <T extends Comparable < ? super T >> void bubblesort(T[] array)
	{
		//TODO Later
	}
	
	public static <T> void bubblesort(T[] array, Comparator<? super T> c)
	{
		//TODO Later
	}
}
