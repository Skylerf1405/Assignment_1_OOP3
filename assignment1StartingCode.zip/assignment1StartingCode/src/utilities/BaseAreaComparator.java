package utilities;

import java.awt.Shape;
import java.util.Comparator;

public class BaseAreaComparator implements Comparator<Shape>
{
	@Override 
	compare(Shape shape1, Shape shape2)
	{
		if (shape1.calcBaseArea() > shape2.calcBaseArea()) return 1;
		if (shape1.calcBaseArea() < shape2.calcBaseArea()) return -1;
	}
	
}
