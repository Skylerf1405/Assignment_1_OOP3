package appDomain;

import utilities.reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.io.FileNotFoundException;

import shapes.*;
import utilities.*;
public class AppDriver
{
	
	
	public static void main( String[] args ) throws FileNotFoundException
	{
		reader shapeReader = new reader();
		Scanner scanner = new Scanner(System.in);
		
		
		boolean exit = false;
		while(!exit)
		{
		
			System.out.println("How many Shapes would you like to sort throuh?");
			System.out.println("1 - 10");
			System.out.println("2 - 1000");
			System.out.println("3 - 1000000");
			System.out.println("4 - Exit");
			
			int option = scanner.nextInt();
			scanner.nextLine();
			
			switch (option)
			{
				case 1: 
					
					break;
				case 2: 
					
					break;
				case 3: 
					
					break;
				case 4:
					exit = true;
					break;
			}
		}

	}

}


		
		//refer to demo001 BasicFileIO.java for a simple example on how to
		// read data from a text file

		// refer to demo01 Test.java for an example on how to parse command
		// line arguments and benchmarking tests

		// refer to demo02 Student.java for comparable implementation, and
		// NameCompare.java or GradeCompare for comparator implementations

		// refer to demo02 KittySort.java on how to use a custom sorting
		// algorithm on a list of comparables to sort using either the
		// natural order (comparable) or other orders (comparators)
