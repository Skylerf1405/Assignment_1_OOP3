package appDomain;

import manager.SortManager;

import java.io.FileNotFoundException;

public class AppDriver {
    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: java -jar Sort.jar -f<file_name> -t<compare_type> -s<sort_algorithm>");
            System.out.println("Example: java -jar Sort.jar -fshapes.txt -tv -sb");
            return;
        }

        String fileName = null;
        String compareType = null;
        String sortAlgorithm = null;

        for (String arg : args) {
            if (arg.startsWith("-f")) {
                fileName = arg.substring(2);
            } else if (arg.startsWith("-t")) {
                compareType = arg.substring(2).toLowerCase();
            } else if (arg.startsWith("-s")) {
                sortAlgorithm = arg.substring(2).toLowerCase();
            }
        }

        if (fileName == null || compareType == null || sortAlgorithm == null) {
            System.out.println("Error: Missing required arguments.");
            return;
        }

        if (!compareType.matches("[hva]")) {
            System.out.println("Error: Invalid compare type. Use 'h' for height, 'v' for volume, or 'a' for base area.");
            return;
        }

        if (!sortAlgorithm.matches("[bsimqz]")) {
            System.out.println("eRror: Invalid sort algorithm. Use 'b' for bubble, 's' for selection, 'i' for insertion, 'm' for merge, 'q' for quick, or 'z' for heap sort.");
            return;
        }

        try {
            SortManager sortManager = new SortManager(args);
            sortManager.readShapes();
            sortManager.sortShapes();
            sortManager.displayResults();
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found - " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
        }
    }
}