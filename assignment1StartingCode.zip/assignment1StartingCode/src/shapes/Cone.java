package shapes;

public class Cone extends Shape
{
	private double radius;

	/**
	 * creates a cone with specified height and radius
	 * @param height
	 * @param radius
	 */
	public Cone(String shapeName, double height, double radius)
	{
		super(shapeName, height);
		this.radius = radius;
	}

	/**
	 * returns the shapes radius
	 * @return the radius
	 */
	public double getRadius()
	{
		return radius;
	}

	/**
	 * sets the shapes radius
	 * @param radius the radius to set
	 */
	public void setRadius(double radius)
	{
		this.radius = radius;
	}

	@Override
	public double calcBaseArea()
	{
		return Math.PI * radius * radius;
	}

	@Override
	public double calcVolume()
	{
		return calcBaseArea() * getHeight() / 3;
	}

	@Override
	public String toString()
	{
		return "Cone - radius: " + getRadius() + ", Base Area: " + calcBaseArea() + ", Volume: "
				+ calcVolume() + ", Height: " + getHeight();
	}
	
	
	
	
}
