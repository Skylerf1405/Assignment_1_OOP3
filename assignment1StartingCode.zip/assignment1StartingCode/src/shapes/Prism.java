package shapes;

/**
 * Prism
 */
public abstract class Prism extends Shape
{
	private double side;

	/**
	 * creates a prism with specified height and side
	 * @param height
	 * @param side
	 */
	public Prism(String shapeName, double height, double side)
	{
		super(shapeName, height);
		this.side = side;
	}

	/**
	 * returns prism side
	 * @return the side
	 */
	public double getSide()
	{
		return side;
	}

	/**
	 * sets prism side
	 * @param side the side to set
	 */
	public void setSide(double side)
	{
		this.side = side;
	}

	

	@Override
	public double calcVolume()
	{
		return calcBaseArea() * getHeight();
	}

	@Override
	public String toString()
	{
		return "Prism - Side: " + getSide() + ", Volume: " + calcVolume() + ", Height: " + getHeight()
				+ ", Base Area" + calcBaseArea();
	}
	
	
	
	
	
	
}
