package shapes;

public abstract class Shape implements Comparable<Shape>
{
	private String shapeName;
	private double height;
	
	/**
	 * Creates a Shape with specified height
	 * @param height the height 
	 */
	public Shape(String shapeName, double height)
	{
		super();
		this.shapeName = shapeName;
		this.height = height;
	}

	/**
	 * Returns the height of the Shape
	 * @return the height
	 */
	public double getHeight()
	{
		return height;
	}

	/**
	 * Sets the height of the Shape
	 * @param height the height to set
	 */
	public void setHeight(double height)
	{
		this.height = height;
	}
	
	/**
	 * gets Name of Shape
	 * @return
	 */
	public String getShapeName()
	{
		return shapeName;
	}
	
	/**
	 * sets Shape Name
	 * @param shapeName
	 */
	public void setShapeName(String shapeName)
	{
		this.shapeName = shapeName; 
	}
	
	@Override
	public int compareTo(Shape other)
	{
		if (this.height > other.height) return 1;
		if (this.height > other.height) return -1;
		return 0;
	}
	
	
	// calculates the base area of the shape 
	public abstract double calcBaseArea();
	
	
	
	//returns calculated volume
	public abstract double calcVolume();

	@Override
	public String toString()
	{
		return "Height: " + getHeight() + "Base Area: " + calcBaseArea() + "Volume: "+ calcVolume();
	}

	}
	
	
	

