package shapes;

public class Cylinder extends Shape
{
	private double radius; 
	
	/**
	 * creates a cylinder with specified height and radius
	 * @param height
	 * @param radius
	 */
	public Cylinder(String shapeName, double height, double radius)
	{
		super(shapeName, height);
		this.radius = radius;
	}
	
	


	/**
	 * @return the radius
	 */
	public double getRadius()
	{
		return radius;
	}




	/**
	 * @param radius the radius to set
	 */
	public void setRadius(double radius)
	{
		this.radius = radius;
	}




	@Override
	public double calcBaseArea()
	{
		return Math.PI * radius * radius;
	}


	@Override
	public double calcVolume()
	{
		return calcBaseArea()* getHeight();
	}




	@Override
	public String toString()
	{
		return "Cylinder - radius: " + radius + ", Base Area: " + calcBaseArea()
				+ ", Volume: " + calcVolume() + ", Height: " + getHeight();
	}
	
	
	
	
}
